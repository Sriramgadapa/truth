
import React, { useState, useCallback } from 'react';
import type { AnalysisResult, GroundingSource } from './types';
import { analyzeText } from './services/geminiService';
import Header from './components/Header';
import AnalysisInput from './components/AnalysisInput';
import AnalysisResultDisplay from './components/AnalysisResultDisplay';
import LoadingSpinner from './components/LoadingSpinner';
import ErrorMessage from './components/ErrorMessage';
import { ThumbsUpIcon, ThumbsDownIcon } from './components/icons';

// --- FeedbackForm Component ---
type Rating = 'helpful' | 'unhelpful' | null;

interface FeedbackFormProps {
  onSubmit: (feedback: { rating: 'helpful' | 'unhelpful'; comment: string }) => void;
}

const FeedbackForm: React.FC<FeedbackFormProps> = ({ onSubmit }) => {
  const [rating, setRating] = useState<Rating>(null);
  const [comment, setComment] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating) {
      onSubmit({ rating, comment });
    }
  };
  
  const getButtonClass = (buttonRating: 'helpful' | 'unhelpful') => {
    let baseClass = "p-3 rounded-full transition-all duration-200 flex items-center space-x-2 text-sm font-semibold";
    if (rating === buttonRating) {
      return buttonRating === 'helpful' 
        ? `${baseClass} bg-green-500/20 text-green-400 ring-2 ring-green-500`
        : `${baseClass} bg-red-500/20 text-red-400 ring-2 ring-red-500`;
    }
    return `${baseClass} bg-brand-bg hover:bg-brand-border text-brand-text-secondary`;
  };

  return (
    <div className="mt-8 bg-brand-surface rounded-lg shadow-lg p-6 animate-slide-up" style={{ animationDelay: '200ms' }}>
      <h3 className="text-xl font-bold mb-4 text-brand-text-primary">Was this analysis helpful?</h3>
      <form onSubmit={handleSubmit}>
        <div className="flex items-center space-x-4 mb-4">
          <button type="button" onClick={() => setRating('helpful')} className={getButtonClass('helpful')} aria-pressed={rating === 'helpful'}>
            <ThumbsUpIcon className="h-5 w-5" />
            <span>Helpful</span>
          </button>
          <button type="button" onClick={() => setRating('unhelpful')} className={getButtonClass('unhelpful')} aria-pressed={rating === 'unhelpful'}>
            <ThumbsDownIcon className="h-5 w-5" />
            <span>Not Helpful</span>
          </button>
        </div>
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Optional: Provide more details..."
          className="w-full h-24 p-3 bg-brand-bg border-2 border-brand-border rounded-md focus:ring-2 focus:ring-brand-blue focus:border-brand-blue transition-colors duration-200 resize-y"
          aria-label="Feedback comment box"
        />
        <div className="mt-4 flex justify-end">
          <button
            type="submit"
            disabled={!rating}
            className="bg-brand-blue hover:bg-opacity-90 disabled:bg-brand-border disabled:cursor-not-allowed text-white font-bold py-2 px-6 rounded-lg transition-all duration-200"
          >
            Submit Feedback
          </button>
        </div>
      </form>
    </div>
  );
};


const App: React.FC = () => {
  const [inputText, setInputText] = useState<string>('');
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [sources, setSources] = useState<GroundingSource[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [feedbackSubmitted, setFeedbackSubmitted] = useState<boolean>(false);

  const handleAnalyze = useCallback(async () => {
    if (!inputText.trim()) {
      setError('Please enter some text to analyze.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);
    setSources([]);
    setFeedbackSubmitted(false);

    try {
      const { analysis, sources } = await analyzeText(inputText);
      setAnalysisResult(analysis);
      setSources(sources);
    } catch (err) {
      console.error(err);
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [inputText]);
  
  const handleSampleText = () => {
      setInputText(`"Scientific study reveals that chocolate is now classified as a vegetable, thanks to its high concentration of cocoa beans. The International Botanical Congress announced this week that the Theobroma cacao tree's fruit, the cocoa bean, shares enough genetic markers with leafy greens to be reclassified. Nutritionists are hailing this as a major breakthrough, allowing for guilt-free indulgence. 'We've always known chocolate had health benefits, but this changes everything,' said Dr. Alistair Finch, a lead researcher on the project. The study, funded by the Global Confectioners Alliance, suggests that three bars of milk chocolate per day can fulfill a person's daily vegetable requirement."`);
  };

  const handleFeedbackSubmit = ({ rating, comment }: { rating: 'helpful' | 'unhelpful'; comment: string }) => {
    const feedbackData = {
      rating,
      comment,
      analyzedText: inputText,
      analysisResult,
      timestamp: new Date().toISOString(),
    };

    try {
      const existingFeedbackJSON = localStorage.getItem('veritas_ai_feedback');
      const existingFeedback = existingFeedbackJSON ? JSON.parse(existingFeedbackJSON) : [];
      existingFeedback.push(feedbackData);
      localStorage.setItem('veritas_ai_feedback', JSON.stringify(existingFeedback));
    } catch (error) {
      console.error("Failed to save feedback to localStorage:", error);
    }

    setFeedbackSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-brand-bg text-brand-text-primary font-sans">
      <Header />
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="bg-brand-surface rounded-lg shadow-2xl p-6 md:p-8 animate-fade-in">
          <AnalysisInput 
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onAnalyze={handleAnalyze}
            onSampleText={handleSampleText}
            isLoading={isLoading}
          />
        </div>

        {isLoading && <LoadingSpinner />}
        {error && !isLoading && <ErrorMessage message={error} />}
        
        {analysisResult && !isLoading && (
          <>
            <AnalysisResultDisplay result={analysisResult} sources={sources} />
            {!feedbackSubmitted ? (
              <FeedbackForm onSubmit={handleFeedbackSubmit} />
            ) : (
              <div className="mt-8 bg-brand-surface rounded-lg shadow-lg p-6 animate-slide-up text-center" style={{ animationDelay: '200ms' }}>
                <h3 className="text-xl font-bold text-green-400">Thank you for your feedback!</h3>
                <p className="text-brand-text-secondary mt-2">Your input helps improve Veritas AI.</p>
              </div>
            )}
          </>
        )}
      </main>
      <footer className="text-center py-4 text-brand-text-secondary text-sm">
        <p>Veritas AI. Powered by Google Gemini.</p>
      </footer>
    </div>
  );
};

export default App;
