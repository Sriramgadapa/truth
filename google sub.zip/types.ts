
export interface RedFlag {
  type: string;
  description: string;
  quote: string;
}

export interface EducationalTip {
  title: string;
  tip: string;
}

export interface AnalysisResult {
  credibilityScore: number;
  summary: string;
  detailedAnalysis: string;
  redFlags: RedFlag[];
  educationalTips: EducationalTip[];
}

export interface GroundingSource {
  web?: {
    uri: string;
    title:string;
  };
}
