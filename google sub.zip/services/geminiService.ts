
import { GoogleGenAI } from "@google/genai";
import type { AnalysisResult, GroundingSource } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `You are 'Veritas', a sophisticated AI misinformation detection engine, powered by a conceptual framework of 100 deep learning transformers. Your sole mission is to analyze text for indicators of misinformation and to empower users with media literacy skills. You must be objective, analytical, and provide actionable advice. Your analysis is based on established indicators like emotional language, loaded words, unverifiable claims, lack of diverse sources, logical fallacies, and sensationalism. You must return your findings *only* as a JSON object inside a single markdown code block. Do not output any text, explanation, or notes outside of the JSON structure in the markdown block.

Your JSON response must conform to this structure:
{
  "credibilityScore": number, // 0-100 score
  "summary": string, // One-sentence summary
  "detailedAnalysis": string, // Detailed paragraph of reasoning
  "redFlags": [{ "type": string, "description": string, "quote": string }],
  "educationalTips": [{ "title": string, "tip": string }]
}`;

const parseJsonResponse = (responseText: string): AnalysisResult => {
  const match = responseText.match(/```json\n([\s\S]*?)\n```/);
  if (!match || !match[1]) {
    throw new Error("Invalid JSON response format from AI.");
  }
  return JSON.parse(match[1]) as AnalysisResult;
};

export const analyzeText = async (text: string): Promise<{ analysis: AnalysisResult; sources: GroundingSource[] }> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ role: 'user', parts: [{ text }] }],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        tools: [{ googleSearch: {} }],
      },
    });

    const analysis = parseJsonResponse(response.text);
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingSource[] || [];

    return { analysis, sources };
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to communicate with the AI engine.");
  }
};
