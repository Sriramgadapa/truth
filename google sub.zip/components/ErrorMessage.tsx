
import React from 'react';
import { AlertCircleIcon } from './icons';

interface ErrorMessageProps {
  message: string;
}

interface ErrorDetails {
    title: string;
    details: string;
    solution?: string;
}

const getErrorDetails = (message: string): ErrorDetails => {
    const lowerCaseMessage = message.toLowerCase();

    if (lowerCaseMessage.includes('please enter some text')) {
        return {
            title: 'Input Required',
            details: 'The analysis cannot start because the text area is empty.',
            solution: 'Please paste some content into the box or use the "Load Sample Text" button to start.',
        };
    }

    if (lowerCaseMessage.includes('invalid json')) {
        return {
            title: 'Unexpected AI Response',
            details: 'The AI returned a response in an unexpected format. This can happen with very unusual or complex input text.',
            solution: 'Try rephrasing your input or analyzing a different piece of content. This is often a temporary issue with the AI model.',
        };
    }

    if (lowerCaseMessage.includes('failed to communicate')) {
        return {
            title: 'Connection Error',
            details: 'Could not connect to the AI analysis engine.',
            solution: 'Please check your internet connection. The service might be experiencing high traffic or could be temporarily down. Please try again in a few moments.',
        };
    }

    // Default catch-all
    return {
        title: 'An Unexpected Error Occurred',
        details: message,
        solution: 'Please try your request again. If you continue to see this message, consider refreshing the application.',
    };
};

const ErrorMessage: React.FC<ErrorMessageProps> = ({ message }) => {
  const { title, details, solution } = getErrorDetails(message);
  return (
    <div className="my-8 p-4 bg-red-900/50 border border-red-500 rounded-lg flex items-start animate-fade-in">
      <AlertCircleIcon className="h-6 w-6 text-red-400 mr-4 mt-1 flex-shrink-0" />
      <div>
        <h3 className="font-bold text-lg text-red-300">{title}</h3>
        <p className="mt-1 text-red-300">{details}</p>
        {solution && (
          <div className="mt-3 pt-3 border-t border-red-500/50">
            <p className="text-sm font-semibold text-red-200">Suggested Action:</p>
            <p className="text-sm text-red-300">{solution}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ErrorMessage;
