import React, { useState } from 'react';
import type { AnalysisResult, GroundingSource, RedFlag, EducationalTip } from '../types';
import CredibilityScore from './CredibilityScore';
import { AlertTriangleIcon, LightbulbIcon, LinkIcon, FileTextIcon, ChevronDownIcon } from './icons';

interface AnalysisResultDisplayProps {
  result: AnalysisResult;
  sources: GroundingSource[];
}

const Section: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode }> = ({ title, icon, children }) => (
    <div className="bg-brand-surface rounded-lg shadow-lg p-6 animate-slide-up" style={{ animationDelay: '100ms' }}>
        <div className="flex items-center mb-4">
            {icon}
            <h2 className="text-xl font-bold ml-3 text-brand-text-primary">{title}</h2>
        </div>
        {children}
    </div>
);

const RedFlagItem: React.FC<{ flag: RedFlag }> = ({ flag }) => {
    const [isExpanded, setIsExpanded] = useState(true);

    // Create a unique ID for ARIA controls
    const contentId = `red-flag-${flag.type.replace(/\s+/g, '-')}-${Math.random().toString(36).substring(2, 9)}`;

    return (
        <div className="bg-brand-bg rounded-md border-l-4 border-yellow-500 mb-3 overflow-hidden">
            <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="w-full p-4 flex justify-between items-center text-left focus:outline-none focus:bg-white/5 transition-colors"
                aria-expanded={isExpanded}
                aria-controls={contentId}
            >
                <h4 className="font-semibold text-yellow-400">{flag.type}</h4>
                <ChevronDownIcon className={`h-5 w-5 text-yellow-400 transition-transform duration-300 ${isExpanded ? 'rotate-180' : 'rotate-0'}`} />
            </button>
            <div
                id={contentId}
                className={`transition-all duration-500 ease-in-out ${isExpanded ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}
                style={{ transitionProperty: 'max-height, opacity' }}
            >
                 <div className="px-4 pb-4 pt-0">
                    <p className="text-sm text-brand-text-secondary">{flag.description}</p>
                    <blockquote className="mt-2 pl-3 border-l-2 border-brand-border text-sm italic">"{flag.quote}"</blockquote>
                </div>
            </div>
        </div>
    );
};

const EducationalTipItem: React.FC<{ tip: EducationalTip }> = ({ tip }) => (
    <div className="p-4 bg-brand-bg rounded-md border-l-4 border-brand-teal mb-3">
        <h4 className="font-semibold text-brand-teal">{tip.title}</h4>
        <p className="text-sm text-brand-text-secondary mt-1">{tip.tip}</p>
    </div>
);

const AnalysisResultDisplay: React.FC<AnalysisResultDisplayProps> = ({ result, sources }) => {
  return (
    <div className="mt-8 space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 bg-brand-surface rounded-lg shadow-lg p-6 flex flex-col items-center justify-center animate-slide-up">
          <h2 className="text-xl font-bold mb-4 text-brand-text-primary">Credibility Score</h2>
          <CredibilityScore score={result.credibilityScore} />
        </div>
        <div className="md:col-span-2 bg-brand-surface rounded-lg shadow-lg p-6 animate-slide-up" style={{ animationDelay: '50ms' }}>
          <div className="flex items-center mb-4">
            <FileTextIcon className="h-6 w-6 text-brand-blue" />
            <h2 className="text-xl font-bold ml-3 text-brand-text-primary">Analysis Summary</h2>
          </div>
          <p className="font-semibold text-brand-text-primary mb-2">{result.summary}</p>
          <p className="text-brand-text-secondary">{result.detailedAnalysis}</p>
        </div>
      </div>

      {result.redFlags.length > 0 && (
          <Section title="Potential Red Flags" icon={<AlertTriangleIcon className="h-6 w-6 text-yellow-400" />}>
              {result.redFlags.map((flag, index) => <RedFlagItem key={index} flag={flag} />)}
          </Section>
      )}

      {result.educationalTips.length > 0 && (
          <Section title="Media Literacy Tips" icon={<LightbulbIcon className="h-6 w-6 text-brand-teal" />}>
              {result.educationalTips.map((tip, index) => <EducationalTipItem key={index} tip={tip} />)}
          </Section>
      )}

      {sources.length > 0 && (
          <Section title="Relevant Sources Found" icon={<LinkIcon className="h-6 w-6 text-brand-blue" />}>
              <ul className="space-y-2">
                  {sources.filter(s => s.web && s.web.uri).map((source, index) => (
                      <li key={index}>
                          <a
                              href={source.web!.uri}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="block p-3 bg-brand-bg hover:bg-opacity-70 rounded-md transition-colors duration-200"
                          >
                              <span className="font-semibold text-brand-blue">{source.web!.title}</span>
                              <span className="block text-xs text-brand-text-secondary truncate">{source.web!.uri}</span>
                          </a>
                      </li>
                  ))}
              </ul>
          </Section>
      )}
    </div>
  );
};

export default AnalysisResultDisplay;